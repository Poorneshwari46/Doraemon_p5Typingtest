<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Register Page</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body style="background-image: url('student-gd38376560_1920.jpg');background-repeat: no-repeat;background-size: cover;background-position: center;"> <br><br>
	<div class="container">
		<div class="row">
			<div class="col-md-3">
			</div>
			<div class="col-md-6 border p-3" style="background:rgba(0, 0, 0, 0.65 );">
				<?php 
				include 'connect.php';

				if(isset($_POST['register'])){
					$name =  trim($_POST['name']);
					$email =  trim($_POST['email']);
					$password =  trim($_POST['password']);

					$check = mysqli_query($conn, "SELECT * FROM `users` WHERE `email` = '$email' ;");

					$count = mysqli_num_rows($check);
					if($count != 0){
						echo '<div class="alert alert-warning">This email is already registered</div>';
					}
					else{
						$save = mysqli_query($conn, "INSERT INTO `users` (`name`, `email`, `password`) VALUES ('$name', '$email', '$password');");
						if($save){
							echo '<div class="alert alert-success">New user created successfully</div>';
						}
						else{
							echo '<div class="alert alert-warning">Unknown error occured try again</div>';
						}
					}

				} ?>
				<h4 class="text-white">Register below</h4>
			<form method="post">
				 <div class="form-group">
    <label for="name" class="text-white">Name:</label>
    <input type="text" class="form-control" id="name" aria-describedby="name" placeholder="Enter name" name="name">
    </div>

  <div class="form-group">
    <label for="exampleInputEmail1" class="text-white">Email address:</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email">
    <small id="emailHelp" class="form-text text-white">We'll never share your email with anyone else.</small>
  </div>

  

  <div class="form-group">
    <label for="exampleInputPassword1" class="text-white">Password:</label>
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="password">
  </div>

  <input type="submit" class="btn btn-info" value="Register Now" name="register">
	</form>
	<hr>
	<p class="text-white">Already have an account? <a href="login.php">Login Here</a></p>
	</div>

			<div class="col-md-3">
			</div>
		</div>
	</div>

</body>
</html>