<?php 
session_start();
if(!$_SESSION['email']){
  header("Location: login.php?login");
}
$email = $_SESSION['email'];
$name = '';
include 'connect.php';
$fetch = mysqli_query($conn,"SELECT * FROM `tests` WHERE `email` = '$email' ORDER by id Desc;");

$count = mysqli_num_rows($fetch);
             



?>
<!DOCTYPE html>
<html ng-app="wpmCalculator">
  <head>
    <title>WPM Calculator</title>
    <meta charset="UTF-8">
    <meta name="description" content="Words per minute calculator built with HTML, CSS, JavaScript, jQuery and Bootstrap.">
    <meta name="author1" content="Ryan Samarajeewa">
    <meta name="author2" content="Andy Yang">

    <!--favicon-->
      <link rel="icon" href="favicon.ico" type="image/png" >
    <!--Font Awesome-->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

    <!--Roboto font from Google-->
      <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

    <!--jQuery-->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

    <!--Bootstrap-->
      <!-- Latest compiled and minified CSS -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
      <!-- Optional theme -->
      <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">-->
      <!-- Latest compiled and minified JavaScript -->
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

    <!--Local stylesheet-->
      <link rel="stylesheet" href="css/styles.css">

    <!--Local script-->
      <script src="js/main.js"></script>

  </head>

  <body>
    <!--header-->
    <div class="jumbotron onesidedropshadow">
      <div class="row container">
        <div class="col-md-6">
      <h3 class="jumbotronText" style="color:#000;">
        <?php echo 'Welcome: '. $name; ?>
       </h3>
     </div>
     <div class="col-md-6 text-right">
      <a href="logout.php">Logout now</a>

     </div>
      </div> <!--// row -->
      
      <h4><a href="index.php">Take a typing test </a></h4>

    </div>


    <div class="container">
      <?php if($count == 0){
        echo '<div class="alert alert-warning">No data found.</div>';

      }
      else{ ?>
        <h1>Your typing test history</h1>
        <table class="table table-bordered">
          <tr>
          <th>SL no  </th>
          <th>WPM</th>
          <th>Error</th>
          <th>Date/Time</th>
        </tr>
        <?php $i = 1;
         while($row=mysqli_fetch_assoc($fetch)){?>

            <tr>
              <td><?php echo $i; $i = $i+1; ?></td>
              <td><?php echo $row['wpm']; ?></td>
              <td><?php echo $row['errs']; ?></td>
              <td><?php echo $row['updated_on']; ?></td>
            </tr>
       <?php } ?>

        </table>



     <?php } 
      ?>
     <hr>
     <h1>Typing Tips:</h1>
    <p> As you prepare to enter the workforce, here are some pointers to improve your own typing skills:</p>
<h3>1.) Use the correct starting position</h3>

<p>When practicing your typing skills, it’s important to use proper hand placement. To start, keep your fingers positioned over the home row keys (left hand over the A, S, D, and F keys, and the right hand over the J, K, L, and ; keys), with your thumbs hovering over the space bar. From here, you can move your fingers slightly to reach neighboring keys. Your hands should always return this starting position.</p>

<p>These conventions are meant to help you familiarize yourself with the keyboard. As you become more experienced, you can experiment with different variations of this starting position to find the placement that is most comfortable and natural for you.</p>
 <h3>2.) Don’t look down your hands</h3>

<p>Instead of looking down at your hands, focus on your screen. This can be difficult at first, especially if you have not yet mastered the exact placement of the keys. However, looking at the screen will help improve your accuracy because you will be able to catch your typos as they occur. You’ll also begin to memorize the placement of the keys, so you’ll be able to type more quickly as you practice.</p>
<h3>3.) Maintain good posture</h3>

<p>Sitting in an upright position is going to make it easier to type faster. If you are used to slouching in your chair or working from the couch, try moving to a straight-backed chair or working at your desk.</p>
<h3>4.) Find a comfortable position for your hands</h3>

<p>The wrong hand placement can make it uncomfortable to type for extended periods of time. The space bar of your keyboard should be centered with your body, so that you are not reading your screen or typing from an angle. As you type, rest your elbows on the table and keep your wrists slightly elevated. You should never bend or angle your wrists dramatically.</p>
<h3>5.) Practice!</h3>

<p>Nothing is mastered overnight, and in order to really improve your typing accuracy and speed, you need to practice every day. There are many websites that offer free typing skills tests and practice, such as Typing Academy, TypingClub and How To Type. It’s important to take your time with these typing exercises and assessments. Attempting to rush through them will only result in more errors at first. Trust that your speed will improve naturally as you become more familiar with the keyboard.</p>

<p><u>Improving your typing skills will not only make your student life much easier, it will benefit you in your future career as well. It might take a lot of practice to see improvement, but don’t give up. You’ll be typing like a pro in no time!</u></p>
    </div>  <!-- // container -->
  </body>

</html>
