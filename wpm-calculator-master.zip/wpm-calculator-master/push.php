<?php 
session_start();
$email = $_SESSION['email'];

include 'connect.php';
if(isset($_GET['wpm'])){
	$wpm = $_GET['wpm'];
	$errors = $_GET['errors'];

	$save = mysqli_query($conn, "INSERT INTO `tests` (`email`, `wpm`, `errs`) VALUES ('$email', '$wpm', '$errors') ;");

 if($save){
 	echo 'Data saved: '.$wpm.', '.$errors;
 }
}


?>