<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "typing_master";

$conn = mysqli_connect($host, $user, $pass, $db);

if(!$conn){
	echo "Connection Failed";
}


?>