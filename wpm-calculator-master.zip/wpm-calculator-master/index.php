<?php 
session_start();
if(!$_SESSION['email']){
  header("Location: login.php?login");
}
$email = $_SESSION['email'];
$name = '';
include 'connect.php';
$fetch = mysqli_query($conn,"SELECT * FROM `users` WHERE `email` = '$email';");

  while($row = mysqli_fetch_assoc($fetch))
  {
     $name = $row['name']; 
   }
  



?>
<!DOCTYPE html>
<html ng-app="wpmCalculator">
  <head>
    <title>WPM Calculator</title>
    <meta charset="UTF-8">
    <meta name="description" content="Words per minute calculator built with HTML, CSS, JavaScript, jQuery and Bootstrap.">
    <meta name="author1" content="Ryan Samarajeewa">
    <meta name="author2" content="Andy Yang">

    <!--favicon-->
      <link rel="icon" href="favicon.ico" type="image/png" >
    <!--Font Awesome-->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

    <!--Roboto font from Google-->
      <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

    <!--jQuery-->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

    <!--Bootstrap-->
      <!-- Latest compiled and minified CSS -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
      <!-- Optional theme -->
      <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">-->
      <!-- Latest compiled and minified JavaScript -->
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

    <!--Local stylesheet-->
      <link rel="stylesheet" href="css/styles.css">

    <!--Local script-->
      <script src="js/main.js"></script>

  </head>

  <body>
    <!--header-->
    <div class="jumbotron onesidedropshadow">
      <div class="row container">
        <div class="col-md-6">
      <h3 class="jumbotronText" style="color:#000;">
        <?php echo 'Welcome: '. $name; ?>
       </h3>
     </div>
     <div class="col-md-6 text-right">
      <a href="logout.php">Logout now</a>

     </div>
      </div> <!--// row -->
      <p class="jumbotronText" style="color:#000;">Test your typing speed.</p>
      <h4><a href="view-reports.php">View Typing Reports</a></h4>

    </div>

    <div class="container-fluid">

      <div class="row ">

        <div class="col-md-12 text-center">
          <h2>Click the textbox, and copy the content on the left.</h2>
        </div>

      </div>

      <div class="row">

        <!--generated paragraphs-->
        <div class="lead paragraph col-md-6  blocks border">
        </div>
        <span id="result"></span>
        <!--textarea-->
        <div class="col-md-6  blocks">
          <div class="form-group ">
            <label for="comment">The timer starts when a key is pressed.</label>
            <button type="button" class="resetBtn btn btn-default"><i class="fa fa-refresh"></i> Reset</button>

            <textarea class="form-control" rows="13" id="userInput" onkeypress="CallBoth(event)" onkeydown="BackSpace(event)"></textarea>
            <!--alert-->
            <div class="alert alert-danger alert-dismissible text-center" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>Warning!</strong> The timer is still running. You must finish typing all of the content!
            </div>

          </div>

        </div>

      </div>

     
      
    </div>

    <div class="container">

    </div>  <!-- // container -->
  </body>

</html>
