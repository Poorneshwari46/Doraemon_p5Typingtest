<?php 
session_start();

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login Page</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body style="background-image: url('student-gd38376560_1920.jpg');background-repeat: no-repeat;background-size: cover;background-position: center;"> <br><br>
	<div class="container">
		<div class="row">
			<div class="col-md-3">
			</div>
			<div class="col-md-6 border p-3" style="background:rgba(0, 0, 0, 0.65 );">
				<?php 
				include 'connect.php';
						if(isset($_POST['login'])){
							$email =  trim($_POST['email']);
							$password =  trim($_POST['password']);

							$check = mysqli_query($conn, "SELECT * FROM `users` WHERE `email` = '$email' AND `password` = '$password';");
							$count = mysqli_num_rows($check);

							if($count == 0){
								echo '<div class="alert alert-warning">No email found, or Password mismatch</div>';

						}
						else{
							
							$_SESSION['email'] = $email;

							header("Location: index.php");
							}
						}

				?>
				<h4 class="text-white"> Login</h4>
			<form method="post">
				

  <div class="form-group">
    <label for="exampleInputEmail1" class="text-white">Email address:</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email">
    
  </div>

  

  <div class="form-group">
    <label for="exampleInputPassword1" class="text-white">Password:</label>
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="password">
  </div>

  <input type="submit" class="btn btn-info" value="Login Now" name="login">
	</form>
	<hr>
	<p class="text-white">Don't have an account? <a href="register.php">Register Here</a></p>
	</div>

			<div class="col-md-3">
			</div>
		</div>
	</div>

</body>
</html>